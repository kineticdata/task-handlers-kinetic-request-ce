{
  'info' => {
    'api_server' => 'https://demo.kineticdata.com/kinetic',
    'api_username' => 'brian.peterson@kineticdata.com',
    'api_password' => 'brian.peterson@kineticdata.com',
    'space_slug' => 'disa'
  },
  'parameters' => {
    'error_handling' => 'Error Message',
	'space_slug' => 'disa',
    'current_username' => 'brian.peterson@kineticdata.com',
    'display_name' => '',
    'email' => 'brian.peterson@kineticdata.com',
    'preferred_locale' => '',
    'enabled' => '',
    'password' => '',
    'space_admin' => '',
    'new_username' => '',
    'attributes' =>  '[{"name": "Author","values": ["1","2"]},{"name": "Attribute Name2","values": ["Attribute Value"]}]',
    'profile_attributes' => '[{"name": "Profile1","values": ["1","2"]},{"name": "Profile2","values": ["Attribute Value"]}]'
  }
}
